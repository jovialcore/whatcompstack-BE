<?php $__env->startSection('content'); ?>
    <div class="col-md-10 mx-auto">

        <div class="card mb-4">
            <h5 class="card-header">Initiate Data Sourcing🪚</h5>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.datasource.initialize')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="exampleFormControlSelect1" class="form-label">Company </label>
                        <select name="company" class="form-select" id="exampleFormControlSelect1"
                            aria-label="Default select example">

                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->name); ?>"><?php echo e($company->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="exampleFormControlSelect1" class="form-label">stack </label>
                        <select name="stack" class="form-select" id="exampleFormControlSelect1"
                            aria-label="Default select example">

                            <?php $__currentLoopData = $stacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($stack->name); ?>"><?php echo e($stack->name); ?> 🌊 </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="exampleFormControlSelect1" class="form-label">Data source </label>
                        <select name="data_source" class="form-select" id="exampleFormControlSelect1"
                            aria-label="Default select example">

                            <?php $__currentLoopData = $dataSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ds->url); ?>"><?php echo e($ds->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Kick off !</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/company stack/BE-whatcompstack/resources/views/admin/scraper.blade.php ENDPATH**/ ?>