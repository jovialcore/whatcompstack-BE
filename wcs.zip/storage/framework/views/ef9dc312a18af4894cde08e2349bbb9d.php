<?php $__env->startSection('content'); ?>
    <h4 class="fw-bold py-2 mb-4"><span class="text-muted fw-light">Stack /</span> Add Stack </h4>

    <?php $__env->startPush('select2style'); ?>
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <?php $__env->stopPush(); ?>
    <div class="col-md-10 mx-auto">

        <div class="card mb-4">
            <?php if($errors->any()): ?>
                <?php echo implode('', $errors->all('<div class="alert alert-danger"> :message </div>')); ?>

            <?php endif; ?>

            <h5 class="card-header">Add Stack 🌠</h5>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.stack.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="exampleFormControlSelect1" class="form-label">Select Company </label>
                        <select name="company" class="form-select" id="exampleFormControlSelect1"
                            aria-label="Default select example">
                            <?php $__currentLoopData = $allStackInfo['allCompanies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->id); ?>"> <?php echo e($company->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="mb-3">
                        <label for="exampleFormControlSelect1" class="form-label">Programming Language </label>
                        <select name="plangs[]" class="form-select stackSelect2MultiPlang" id=""
                            aria-label="Default select example" multiple>
                            <?php $__currentLoopData = $allStackInfo['allPlangs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($plang->id); ?>"> <?php echo e($plang->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="exampleFormControlSelect1" class="form-label">Programming Language </label>
                        <select name="frameworks[]" class="form-select stackSelect2MultiFramework" id=""
                            aria-label="Default select example" multiple>
                            <?php $__currentLoopData = $allStackInfo['allFrameworks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $framework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($framework->id); ?>"> <?php echo e($framework->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>

            </div>
        </div>
    </div>


    <?php $__env->startPush('select2script'); ?>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

        <script>
            $(".stackSelect2MultiPlang").select2({

                placeholder: "Select Programming Language"

            });
            $(".stackSelect2MultiFramework").select2({
                placeholder: "Select Framework"
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/company stack/BE-whatcompstack/resources/views/admin/stack/create.blade.php ENDPATH**/ ?>