<?php $__env->startSection('content'); ?>
    <div class="col-md-10 mx-auto">

        <div class="card mb-4">

            <?php if($errors->any()): ?>
                <?php echo implode('', $errors->all('<div class="alert alert-danger"> :message </div>')); ?>

            <?php endif; ?>

            <h5 class="card-header">Add Source 🐾 </h5>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.source.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label class="form-label" for="basic-default-fullname">Source name</label>
                        <input type="text" name="data_source_name" class="form-control" id="basic-default-fullname"
                            placeholder="source name" value="<?php echo e(old('data_source_name')); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="basic-default-fullname">Source Link</label>
                        <input type="text" name="data_source_url" class="form-control" id="basic-default-fullname"
                            placeholder="wwww.something.com" value="<?php echo e(old('data_source_url')); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/company stack/BE-whatcompstack/resources/views/admin/source/create.blade.php ENDPATH**/ ?>