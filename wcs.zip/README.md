#### Still Under Development but we lauching soon. Anything you are seeing is look-alike !
### Backend stack for whatcompanystackk

[Web app: User interface ](https://whatcompanystack.com)


![image](https://github.com/jovialcore/whatcompstack-BE/assets/32295501/0f322691-226d-4671-b779-e64f7aedf413)

### Sneak Peek of Admin: 
 Some other features are currently under development.
![Screenshot from 2023-11-23 12-09-04](https://github.com/jovialcore/whatcompstack-BE/assets/32295501/9542b07f-34d7-4f8c-85c1-75e2a544af74)

![dashbooorddd](https://github.com/jovialcore/whatcompstack-BE/assets/32295501/4d8f21a2-b46c-46b5-8dae-a6e6cb22814c)



