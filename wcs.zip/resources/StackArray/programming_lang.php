<?php
return  [
    'PHP',      // id: 1
    'Python',   // id: 2
    'Ruby',     // id: 3
    'Java',     // id: 4
    'C#',       // id: 5
    'Go',       // id: 6
    'Rust',     // id: 7
    'Node.js',  // id: 8
    'Elixir',   // id: 9
    'Perl',     // id: 10
    'Haskell',  // id: 11
    'Swift',    // id: 12
    'Kotlin',   // id: 13
    'Scala',    // id: 14
    'Clojure',  // id: 15
    'Erlang',   // id: 16
    'Objective-C', // id: 18
    'Julia',    // id: 21
    'R',        // id: 20
    'Lua',      // id: 19

];
