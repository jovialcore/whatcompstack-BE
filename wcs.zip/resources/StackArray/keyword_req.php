<?php


return [
    'requirements',
    'nice to haves',
    'requirement',
    'Required competency and skillset to be a Waver',
    'What Your Day to Day Activities Will Be Like:',
    'required',
    'Qualifications',
    'Characteristics',
    'Qualifications Characteristics',
    'What We Look For in You',
    'Required competency and skillset to be a Waver'
];
