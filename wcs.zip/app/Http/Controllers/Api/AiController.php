<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Orhanerday\OpenAi\OpenAi;
use Aws\Textract\TextractClient;
use Aws\Textract\Exception\TextractException;


class AiController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    protected $file;

    public function upload(Request $req)
    {

        // if there is no image, just use the default
        if (!$req->hasFile('image')) {

            $this->file = storage_path('testimage/imagewithhandwrittenpen.jpeg');
        } else {

            $validator = Validator::make($req->all(), [
                'image' => 'required|file|mimes:jpg,png,webp',
                'text' => 'string|max:1000|min:7'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'errors' => $validator->errors()
                ], 422);
            }

            $this->file = $req->file('image')->getRealPath();
        }

        $textractClient = new TextractClient([
            'version' => 'latest',
            'region' => env('AWS_REGION'),
            'credentials' => [
                'key'    => env('AWS_KEY'),
                'secret' => env('AWS_SECRET')
            ],
            'scheme' => 'https',
        ]);


        try {
            $result = $textractClient->detectDocumentText([
                'Document' => [
                    'Bytes' => file_get_contents($this->file)
                ]
            ]);

            $words = "";
            foreach ($result->get('Blocks') as $block) {
                if ($block['BlockType'] != 'WORD') {
                    continue;
                }

                $words = $words . $block['Text'] . " ";
            }
        } catch (TextractException $e) {
            // output error message if fails
            return response()->json(['error' => $e->getMessage()]);
        }

        $openaikey = env('OPENAI_API_KEY');

        $open_ai = new OpenAi($openaikey);

        $textToUse  = 'Explain this ' . $words;
        if (!empty($req->text) && !is_null($req->text)) {
            $textToUse = $req->text . ' ' . $words;
        }

        $chat =   $open_ai->chat([
            'model' => 'gpt-3.5-turbo',
            'messages' => [

                [
                    "role" => "user",
                    "content" => "Please note:These contents where extracted from an Image extraction api. If you don't understand, just say you don't understand. Avoid using words like 'as an AI model', or any disclaimer at all!. Just explain the much you can:  $textToUse"
                ],
            ],

        ]);

        $d = json_decode($chat);

        dd($d);
        $r = $d->choices[0]->message->content;

        return response()->json(['data' => $r], 200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
