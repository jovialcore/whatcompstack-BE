<?php

namespace App\Services\Api;


class CompanyService
{
}
