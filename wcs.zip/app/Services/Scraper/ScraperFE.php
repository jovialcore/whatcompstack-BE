<?php



class ScraperFE
{
    public function __construct()
    {

    }


    
}
